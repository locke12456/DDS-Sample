//----------------------------------------------------------------
//
//-- ILS Technology
//-- C Platform Independent Library
//
//-- Filename: ils/util/base64.h
//
//-- Copyright: 2001-2013, ILS Technology, LLC
//
//----------------------------------------------------------------

#ifndef ILS_UTIL_PACKING_H_
#define ILS_UTIL_PACKING_H_

#ifdef __cplusplus
extern "C" {
#endif

// START OF PACKING
//#if defined(_WIN32)
//#  pragma pack(1)
//#elif defined(_UNIX)
//#  if defined(__GNUC__)
//#  else
//#    pragma options align=packed
//#  endif
//#endif
// START OF PACKING
	
// END OF PACKING
//#if defined(_WIN32)
//#  pragma pack()
//#elif defined(_UNIX)
//#  if defined(__GNUC__)
//#  else
//#    pragma options align=reset
//#  endif
//#endif
// END OF PACKING

// STRUCT PACKING
//#if defined(__GNUC__)
//__attribute ((packed))
//#endif
// STRUCT PACKING
	
#ifdef __cplusplus
}
#endif

#endif /*ILS_UTIL_PACKING_H_*/
